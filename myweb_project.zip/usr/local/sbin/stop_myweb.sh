#!/bin/bash
PID=$(cat /var/run/myweb.pid)
kill $PID