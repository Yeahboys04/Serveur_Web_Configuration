#!/bin/bash
java -cp /usr/local/sbin/myweb MyWebServer