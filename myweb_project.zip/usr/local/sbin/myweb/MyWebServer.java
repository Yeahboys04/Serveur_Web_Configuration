import java.io.*;
import java.net.*;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import java.util.*;
import java.util.concurrent.*;
import java.nio.file.*;
import java.text.*;
import java.util.logging.*;

/**
 * Classe principale du serveur web MyWebServer
 */
public class MyWebServer {
    private static int port = 80;
    private static String rootDirectory = ".";
    private static List<String> acceptedIPs = new ArrayList<>();
    private static List<String> rejectedIPs = new ArrayList<>();
    private static Logger accessLogger;
    private static Logger errorLogger;

    public static void main(String[] args) {
        ConfigLoader.loadConfig("/etc/myweb/myweb.conf");
        try (ServerSocket serverSocket = new ServerSocket(port)) {
            // Enregistre le PID du processus
            try (PrintWriter out = new PrintWriter("/var/run/myweb.pid")) {
                out.println(ProcessHandle.current().pid());
            }
            System.out.println("Serveur démarré sur le port " + port);
            ExecutorService executor = Executors.newFixedThreadPool(10);
            while (true) {
                Socket clientSocket = serverSocket.accept();
                executor.submit(new RequestHandler(clientSocket));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Charge la configuration depuis le fichier XML spécifié
     */
    static class ConfigLoader {
        public static void loadConfig(String filePath) {
            try {
                File configFile = new File(filePath);
                DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
                DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
                Document doc = dBuilder.parse(configFile);
                doc.getDocumentElement().normalize();

                port = Integer.parseInt(doc.getElementsByTagName("port").item(0).getTextContent());
                rootDirectory = doc.getElementsByTagName("root").item(0).getTextContent();

                NodeList acceptList = doc.getElementsByTagName("accept");
                for (int i = 0; i < acceptList.getLength(); i++) {
                    acceptedIPs.add(acceptList.item(i).getTextContent());
                }

                NodeList rejectList = doc.getElementsByTagName("reject");
                for (int i = 0; i < rejectList.getLength(); i++) {
                    rejectedIPs.add(rejectList.item(i).getTextContent());
                }

                String accessLogPath = doc.getElementsByTagName("acceslog").item(0).getTextContent();
                String errorLogPath = doc.getElementsByTagName("errorlog").item(0).getTextContent();

                accessLogger = Logger.getLogger("AccessLog");
                accessLogger.addHandler(new FileHandler(accessLogPath, true));
                errorLogger = Logger.getLogger("ErrorLog");
                errorLogger.addHandler(new FileHandler(errorLogPath, true));

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Gère les requêtes des clients
     */
    static class RequestHandler implements Runnable {
        private Socket clientSocket;

        public RequestHandler(Socket socket) {
            this.clientSocket = socket;
        }

        @Override
        public void run() {
            try {
                BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                BufferedWriter out = new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream()));

                String requestLine = in.readLine();
                if (requestLine == null || requestLine.isEmpty()) {
                    return;
                }

                StringTokenizer tokenizer = new StringTokenizer(requestLine);
                String method = tokenizer.nextToken();
                String requestedFile = tokenizer.nextToken();

                InetAddress clientAddress = clientSocket.getInetAddress();
                if (isRejected(clientAddress)) {
                    sendErrorResponse(out, 403, "Forbidden");
                    return;
                }

                if (isAccepted(clientAddress)) {
                    if (requestedFile.equals("/status")) {
                        StatusPage.sendStatus(out);
                    } else {
                        File file = new File(rootDirectory, requestedFile);
                        if (file.exists() && !file.isDirectory()) {
                            sendFileResponse(out, file);
                        } else {
                            sendErrorResponse(out, 404, "Not Found");
                        }
                    }
                } else {
                    sendErrorResponse(out, 403, "Forbidden");
                }
                accessLogger.info(requestLine);
            } catch (IOException e) {
                errorLogger.severe(e.getMessage());
                e.printStackTrace();
            }
        }

        private boolean isAccepted(InetAddress address) {
            // Logique pour vérifier les IP acceptées
            return true;
        }

        private boolean isRejected(InetAddress address) {
            // Logique pour vérifier les IP rejetées
            return false;
        }

        private void sendFileResponse(BufferedWriter out, File file) throws IOException {
            String contentType = Files.probeContentType(file.toPath());
            String base64Content = Base64.getEncoder().encodeToString(Files.readAllBytes(file.toPath()));
            out.write("HTTP/1.1 200 OK
");
            out.write("Content-Type: " + contentType + "
");
            out.write("Content-Encoding: base64
");
            out.write("
");
            out.write(base64Content);
            out.flush();
        }

        private void sendErrorResponse(BufferedWriter out, int statusCode, String message) throws IOException {
            out.write("HTTP/1.1 " + statusCode + " " + message + "
");
            out.write("Content-Type: text/html
");
            out.write("
");
            out.write("<html><body><h1>" + statusCode + " " + message + "</h1></body></html>");
            out.flush();
        }
    }

    /**
     * Génère et envoie la page de statut du serveur
     */
    static class StatusPage {
        public static void sendStatus(BufferedWriter out) throws IOException {
            long freeMemory = Runtime.getRuntime().freeMemory();
            long freeDiskSpace = new File("/").getFreeSpace();
            int processCount = new File("/proc").list().length;

            out.write("HTTP/1.1 200 OK
");
            out.write("Content-Type: text/html
");
            out.write("
");
            out.write("<html><body><h1>Statut du Serveur</h1>");
            out.write("<p>Mémoire disponible: " + freeMemory + " octets</p>");
            out.write("<p>Espace disque disponible: " + freeDiskSpace + " octets</p>");
            out.write("<p>Nombre de processus: " + processCount + "</p>");
            out.write("</body></html>");
            out.flush();
        }
    }
}
