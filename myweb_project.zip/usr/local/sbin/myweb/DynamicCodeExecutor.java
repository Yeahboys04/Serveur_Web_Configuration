import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.file.*;
import org.w3c.dom.*;

public class DynamicCodeExecutor {
    public static String executeCode(String code, String interpreter) {
        try {
            ProcessBuilder builder = new ProcessBuilder(interpreter);
            Process process = builder.start();
            OutputStream os = process.getOutputStream();
            os.write(code.getBytes());
            os.flush();
            os.close();

            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            StringBuilder output = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line).append("
");
            }
            reader.close();
            process.waitFor();
            return output.toString();
        } catch (Exception e) {
            e.printStackTrace();
            return "Erreur lors de l'exécution du code.";
        }
    }
}
